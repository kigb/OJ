/*
 Navicat Premium Data Transfer

 Source Server         : hoj
 Source Server Type    : MySQL
 Source Server Version : 80032 (8.0.32)
 Source Host           : localhost:3306
 Source Schema         : online_oj

 Target Server Type    : MySQL
 Target Server Version : 80032 (8.0.32)
 File Encoding         : 65001

 Date: 12/07/2023 14:21:44
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `username` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `password` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `ismanager` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`username`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('134', 'gh3', 0);
INSERT INTO `admin` VALUES ('root', 'root', 1);
INSERT INTO `admin` VALUES ('root1', 'root1', 0);
INSERT INTO `admin` VALUES ('root2', 'root2', 0);

-- ----------------------------
-- Table structure for judgeproblem
-- ----------------------------
DROP TABLE IF EXISTS `judgeproblem`;
CREATE TABLE `judgeproblem`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `level` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `template_code` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `time_limit` int NULL DEFAULT NULL,
  `memory_limit` int NULL DEFAULT NULL,
  `stdin` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `expected_out` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of judgeproblem
-- ----------------------------

-- ----------------------------
-- Table structure for problem
-- ----------------------------
DROP TABLE IF EXISTS `problem`;
CREATE TABLE `problem`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `level` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL,
  `templateCode` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL,
  `testCode` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL,
  `test_in` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `test_out` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `in_case` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `out_case` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 112 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of problem
-- ----------------------------
INSERT INTO `problem` VALUES (1, '两数之和', '两数之和', '计算两数之和xy', '12', '6', '', '', NULL, NULL);
INSERT INTO `problem` VALUES (2, '整数反转', '中等', '给你一个 32 位的有符号整数 x ，返回将 x 中的数字部分反转后的结果。\n\n如果反转后整数超过 32 位的有符号整数的范围 [−231,  231 − 1] ，就返回 0。\n\n假设环境不允许存储 64 位整数（有符号或无符号）。\n\n', 'class Solution {\npublic:\n    int reverse(int x) {\n\n    }\n};', '', '1224', '4221', NULL, NULL);
INSERT INTO `problem` VALUES (3, '输出hello', '简单', '打印helloworld', 'public class HelloWorld {\n   \n}', '', NULL, 'Hello,World!', NULL, NULL);
INSERT INTO `problem` VALUES (4, '测试用例', '测试', '测试题目添加', '测试模板', ' //s', 'test', 'test success！', NULL, NULL);
INSERT INTO `problem` VALUES (6, '6', '6', '6', '6', '6', NULL, NULL, '第一行包含两个整数 n 和 m，表示矩阵的行数和列数 (1≤n≤100，1≤m≤100)。接下来 n 行，每行 m 个整数，表示矩阵 A 的元素。接下来 n 行，每行 m 个整数，表示矩阵 B 的元素。相邻两个整数之间用单个空格隔开，每个元素均在 1∼1000 之间。', 'n 行，每行 m 个整数，表示矩阵加法的结果。相邻两个整数之间用单个空格隔开。');

-- ----------------------------
-- Table structure for testcase
-- ----------------------------
DROP TABLE IF EXISTS `testcase`;
CREATE TABLE `testcase`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `problem_id` int NOT NULL,
  `test_in` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `test_out` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `testcase_problem_id_fk`(`problem_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 28 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of testcase
-- ----------------------------
INSERT INTO `testcase` VALUES (8, 100, '1 3', '6');
INSERT INTO `testcase` VALUES (9, 100, '2', '7');
INSERT INTO `testcase` VALUES (10, 100, '4', '9');
INSERT INTO `testcase` VALUES (23, 1, '1 2', '3');
INSERT INTO `testcase` VALUES (24, 1, '3 6', '9');
INSERT INTO `testcase` VALUES (25, 1, '2147483647 1', '2147483648');
INSERT INTO `testcase` VALUES (27, 6, '', '6');

-- ----------------------------
-- Table structure for user_answer
-- ----------------------------
DROP TABLE IF EXISTS `user_answer`;
CREATE TABLE `user_answer`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `pass_count` int(10) UNSIGNED ZEROFILL NOT NULL,
  `total_count` int(10) UNSIGNED ZEROFILL NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `problem_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_user_name_user`(`user_name` ASC) USING BTREE,
  INDEX `fk_problem_id_problem`(`problem_id` ASC) USING BTREE,
  CONSTRAINT `fk_problem_id_problem` FOREIGN KEY (`problem_id`) REFERENCES `problem` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `fk_user_name_user` FOREIGN KEY (`user_name`) REFERENCES `admin` (`username`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of user_answer
-- ----------------------------
INSERT INTO `user_answer` VALUES (9, 0000000029, 0000000041, 'root', 1);
INSERT INTO `user_answer` VALUES (13, 0000000002, 0000000006, 'root2', 1);
INSERT INTO `user_answer` VALUES (16, 0000000001, 0000000001, 'root', 6);

SET FOREIGN_KEY_CHECKS = 1;
