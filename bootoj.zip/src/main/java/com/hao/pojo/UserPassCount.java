package com.hao.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserPassCount {
    private String user_name;
    private int pass_count_records;

    // 省略getter和setter方法
}
