package com.hao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author haozhang
 */

@SpringBootApplication
//@MapperScan("com.hao.mapper")
public class BootojApplication {
    public static void main(String[] args) {
        SpringApplication.run(BootojApplication.class, args);
    }

}
