package com.hao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootojApplicationTests {

    @Test
    void contextLoads() {
    }
}
